from django.urls import path
from . import views

urlpatterns = [
    path("", views.chat, name="chat"),
    path("messages/<int:user_id>/", views.messages, name="messages"),
]
