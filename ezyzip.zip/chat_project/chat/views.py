from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import User, Message

@login_required
def chat(request):
    users = User.objects.exclude(id=request.user.id)  # Exclude current user
    return render(request, "chat/chat.html", {"users": users})

@login_required
def messages(request, user_id):
    other_user = User.objects.get(id=user_id)
    messages = Message.objects.filter(
        sender=request.user, recipient=other_user
    ) | Message.objects.filter(
        sender=other_user, recipient=request.user
    )
    return render(request, "chat/messages.html", {"messages": messages, "other_user": other_user})
